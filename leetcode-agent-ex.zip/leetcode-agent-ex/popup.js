// Run this immediately when the popup opens
// Helper function to check if a JWT token is expired
function isTokenExpired(token) {
  if (!token) return true;
  try {
    // Decode the payload part of the JWT
    const payload = JSON.parse(atob(token.split('.')[1]));
    // JWT exp is in seconds, JS Date.now() is in milliseconds
    return payload.exp * 1000 < Date.now();
  } catch (error) {
    // If the token is malformed, treat it as expired
    return true; 
  }
}

// Check auth status on load
chrome.storage.local.get(['authToken'], (result) => {
  if (result.authToken && !isTokenExpired(result.authToken)) {
    // Token exists and is NOT expired
    document.getElementById('login-view').classList.add('hidden');
    document.getElementById('dashboard-view').classList.remove('hidden');
  } else {
    // Token is missing, or it IS expired. Clean up storage just in case.
    chrome.storage.local.remove(['authToken', 'userId']);
  }
});

// Login functionality
document.getElementById('login-btn').addEventListener('click', async () => {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const response = await fetch('https://backend-p1-jyz6.onrender.com/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (response.ok) {
      const data = await response.json();
      
      chrome.storage.local.set({ authToken: data.token, userId: data.userId }, () => {
        document.getElementById('login-view').classList.add('hidden');
        document.getElementById('dashboard-view').classList.remove('hidden');
        document.getElementById('error-msg').innerText = ""; // Clear errors
      });
    } else {
      document.getElementById('error-msg').innerText = "Invalid credentials";
    }
  } catch (error) {
    document.getElementById('error-msg').innerText = "Server error";
  }
});

// Logout functionality
document.getElementById('logout-btn').addEventListener('click', () => {
  // 1. Remove the token and user data from storage
  chrome.storage.local.remove(['authToken', 'userId'], () => {
    // 2. Swap the UI back to the login screen
    document.getElementById('dashboard-view').classList.add('hidden');
    document.getElementById('login-view').classList.remove('hidden');
    
    // 3. Clear out the old form data and statuses
    document.getElementById('email').value = "";
    document.getElementById('password').value = "";
    document.getElementById('statusText').innerText = ""; 
  });
});

// Sync functionality
document.addEventListener("DOMContentLoaded", () => {
  const syncButton = document.getElementById("syncButton");
  const statusText = document.getElementById("statusText");

  if (!syncButton || !statusText) {
    console.error("Critical: Could not find syncButton or statusText element in DOM!");
    return;
  }

  syncButton.addEventListener("click", () => {
    console.log("Sync button clicked!");
    statusText.innerText = "Syncing... Please wait.";
    syncButton.disabled = true;

    chrome.runtime.sendMessage({ type: "START_SYNC" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Communication error:", chrome.runtime.lastError.message);
        statusText.innerText = "Error: Background script unreachable.";
        return;
      }

      console.log("Response from background:", response);
      if (!response || response.status !== "Success") {
        if (statusText.innerText === "Syncing... Please wait.") {
          statusText.innerText = "Error: Check Service Worker console.";
        }
        syncButton.disabled = false;
      }
    });
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type !== 'SYNC_PROGRESS') return;
    const progress = message.progress || {};
    const totals = [
      progress.fetched != null && `Fetched: ${progress.fetched}`,
      progress.unique != null && `Unique: ${progress.unique}`,
      progress.imported != null && `Imported: ${progress.imported}`,
      progress.skippedExisting != null && `Already synced: ${progress.skippedExisting}`,
      progress.skippedMissingMetadata != null && `Skipped: ${progress.skippedMissingMetadata}`
    ].filter(Boolean).join(' · ');
    statusText.innerText = [progress.stage, totals].filter(Boolean).join('\n');
    statusText.style.color = progress.error ? 'red' : progress.complete ? 'green' : '#333';
    syncButton.disabled = !progress.complete && !progress.error;
  });
});
