chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_SYNC") {
    // Run our sync function, then reply to the popup when done
    startSyncing().then((success) => {
      sendResponse({ status: success ? "Success" : "Failed" });
    });
    return true; // Tells Chrome we will send the response asynchronously 
  }
});

const API_BASE_URL = 'https://backend-p1-jyz6.onrender.com';
const IMPORT_BATCH_SIZE = 200;
function report(progress) {
  chrome.runtime.sendMessage({ type: 'SYNC_PROGRESS', progress }).catch(() => {});
}

async function startSyncing() {
  report({ stage: 'Checking your LeetCode sign-in…' });
  const checkpoint = (await chrome.storage.local.get(['leetcodeSyncCheckpoint'])).leetcodeSyncCheckpoint;
  const previousNewestSubmissionId = checkpoint?.lastSubmissionId || null;
  // =========================================================
  // 1. Get the security cookie from LeetCode
  // =========================================================
  const cookie = await chrome.cookies.get({
    url: "https://leetcode.com",
    name: "csrftoken"
  });

  if (!cookie) {
    console.error("User is not logged in.");
    return false;
  }

  const csrfToken = cookie.value;

  // =========================================================
  // 2. Get current LeetCode username
  // =========================================================
  const userResponse = await fetch("https://leetcode.com/graphql", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-csrftoken": csrfToken
    },
    body: JSON.stringify({
      query: `
        query {
          userStatus {
            username
            isSignedIn
          }
        }
      `
    })
  });

  const userData = await userResponse.json();
  const username = userData?.data?.userStatus?.username;

  if (!username) {
    console.error("Could not find username. Are you fully logged in?");
    return false;
  }

  console.log("Syncing history for user:", username);

  // =========================================================
  // 3. Fetch ALL submissions (ADDED 'lang' to query)
  // =========================================================
  let offset = 0;
  let hasNext = true;
  const allSubmissions = [];

  while (hasNext) {
    report({ stage: `Downloading submissions… ${allSubmissions.length} found` });
    const response = await fetch("https://leetcode.com/graphql", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-csrftoken": csrfToken,
        "Origin": "https://leetcode.com",
        "Referer": "https://leetcode.com/"
      },
      body: JSON.stringify({
        query: `
          query submissionList($offset: Int!, $limit: Int!) {
            submissionList(offset: $offset, limit: $limit) {
              hasNext
              submissions {
                id
                titleSlug
                statusDisplay
                lang
                timestamp
              }
            }
          }
        `,
        variables: {
          offset: offset,
          limit: 20
        }
      })
    });

    const data = await response.json();

    if (data.errors) {
      console.error("LeetCode submission query failed:", data.errors);
      return false;
    }

    const list = data?.data?.submissionList;
    if (!list) {
      console.error("No submission data returned.");
      return false;
    }

    allSubmissions.push(...list.submissions);
    // LeetCode returns newest-first. Once the prior newest event is reached, all
    // newer events have been collected and older pages can be skipped.
    const reachedCheckpoint = previousNewestSubmissionId &&
      list.submissions.some(submission => String(submission.id) === previousNewestSubmissionId);
    hasNext = list.hasNext && !reachedCheckpoint;
    offset += 20;

    await new Promise(resolve => setTimeout(resolve, 500));
  }

  const submissionsById = new Map(allSubmissions.filter(row => row?.id != null).map(row => [String(row.id), row]));
  const uniqueSubmissions = [...submissionsById.values()];
  report({ stage: `Resolving ${uniqueSubmissions.length} unique submissions…`, fetched: allSubmissions.length, unique: uniqueSubmissions.length });

  // =========================================================
  // 4. Extract unique problem slugs
  // =========================================================
  
  const uniqueSlugs = [
    ...new Set(uniqueSubmissions.map(submission => submission.titleSlug).filter(slug => typeof slug === 'string'))
  ];

  console.log("Unique problems found:", uniqueSlugs.length);

  // =========================================================
  // 5. Fetch problem metadata
  // =========================================================
  const problemData = {};
  const BATCH_SIZE = 50;

  for (let i = 0; i < uniqueSlugs.length; i += BATCH_SIZE) {
    const batch = uniqueSlugs.slice(i, i + BATCH_SIZE);

    const queryFields = batch
      .map((slug, index) => {
        return `
          q${index}: question(titleSlug: $slug${index}) {
            questionId
            title
            difficulty
            topicTags {
              name
              slug
            }
          }
        `;
      })
      .join("\n");

    const query = `
      query problemMetadata(${batch.map((_, index) => `$slug${index}: String!`).join(', ')}) {
        ${queryFields}
      }
    `;

    const response = await fetch("https://leetcode.com/graphql", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-csrftoken": csrfToken,
        "Origin": "https://leetcode.com",
        "Referer": "https://leetcode.com/"
      },
      body: JSON.stringify({ query, variables: Object.fromEntries(batch.map((slug, index) => [`slug${index}`, slug])) })
    });

    const data = await response.json();
    
    if (data.errors) {
      console.error("Problem metadata query failed:", data.errors);
      report({ stage: 'Problem metadata could not be verified. No data was imported.', error: true });
      return false;
    }

    batch.forEach((slug, index) => {
      const problem = data?.data?.[`q${index}`];
      if (!problem) {
        console.warn("Problem metadata missing:", slug);
        return;
      }

      problemData[slug] = {
        problemcode: problem.questionId, // lowercase to match backend
        problemtitle: problem.title,     // renamed from title to problemtitle
        difficulty: problem.difficulty,
        tags: problem.topicTags.map(tag => tag.slug)
      };
    });

    await new Promise(resolve => setTimeout(resolve, 300));
  }

  console.log("Problem metadata collected:", Object.keys(problemData).length);

  // =========================================================
  // 6. Create normalized submission rows
  // =========================================================
  const submissions = [];
  let skippedMissingMetadata = 0;

  for (const submission of uniqueSubmissions) {
    const problem = problemData[submission.titleSlug];

    if (!problem) {
      console.warn("Skipping submission because problem metadata is missing:", submission.titleSlug);
      skippedMissingMetadata++;
      continue;
    }

    // Convert LeetCode's second-based timestamp to millisecond-based BigInt string/number
    const msTimestamp = Number(submission.timestamp) * 1000;

    submissions.push({
      // -----------------------------
      // Problem information
      // -----------------------------
      problemcode: problem.problemcode,
      problemtitle: problem.problemtitle,
      titleSlug: submission.titleSlug,
      difficulty: problem.difficulty,
      tags: problem.tags,

      // -----------------------------
      // Submission information
      // -----------------------------
      status: submission.statusDisplay,
      language: submission.lang || null, // Included language
      timestamp: msTimestamp.toString(), // Milliseconds
      platformSubmissionId: String(submission.id)
    });
  }

  // =========================================================
  // 7. Get authentication information
  // =========================================================
  const result = await chrome.storage.local.get(["authToken"]);
  const token = result.authToken;

  const result2 = await chrome.storage.local.get(["userId"]);
  const userId = result2.userId;

  if (!token || !userId) {
    console.error("Authentication missing. User is not logged in.");
    return false;
  }

  // =========================================================
  // 8. Create payload & Send to backend
  // =========================================================
  let imported = 0;
  let skippedExisting = 0;
  for (let offset = 0; offset < submissions.length; offset += IMPORT_BATCH_SIZE) {
    const batch = submissions.slice(offset, offset + IMPORT_BATCH_SIZE);
    report({ stage: `Importing batch ${Math.floor(offset / IMPORT_BATCH_SIZE) + 1} of ${Math.ceil(submissions.length / IMPORT_BATCH_SIZE)}…`,
      fetched: allSubmissions.length, unique: uniqueSubmissions.length, imported, skippedMissingMetadata, skippedExisting });
    const response = await fetch(`${API_BASE_URL}/api/imports/leetcode/${userId}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ platform: 'Leetcode', submissions: batch })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      report({ stage: result.message || `Import failed (${response.status}).`, error: true });
      return false;
    }
    imported += result.result?.submissionsProcessed || 0;
    skippedExisting += result.result?.skippedExisting || 0;
  }
  await chrome.storage.local.set({ leetcodeSyncCheckpoint: { completedAt: Date.now(), lastSubmissionId: submissions[0]?.platformSubmissionId || null } });
  report({ stage: 'Sync complete.', fetched: allSubmissions.length, unique: uniqueSubmissions.length,
    imported, skippedMissingMetadata, skippedExisting, complete: true });
  return true;
}
